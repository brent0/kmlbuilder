-------------------------------------------------------------------------------
INFO

This package is a BETA release. Please send any feedback (errors found, desired 
upgrades, ...) to:

Brent.Cameron@dfo-mpo.gc.ca

--------------------------------------------------------------------------------


EXAMPLES

Examples can be found in the documentation for this package. 

--------------------------------------------------------------------------------

INSTALLATION

You may need to install dependencies first, just issue(copy paste)
the folowing commands to R, packages will be installed only if they
do not already exist:

if(!require("rgdal", character.only=T))install.packages("rgdal", dep = T)
if(!require("RCurl", character.only=T))install.packages("RCurl", dep = T)
if(!require("R.oo", character.only=T))install.packages("R.oo", dep = T)


Copy and paste the kmlbuilder_1.1.3.tar.gz found in this directory on your 
filesystem (your_path).


Install this package from R by issuing the R command:


install.packages("C:/Users/yourusername/your_path/kmlbuilder_1.1.7.tar.gz", 
repos = NULL, type = "source")

----------------------------------------------------------------------------------

ENJOY!!
